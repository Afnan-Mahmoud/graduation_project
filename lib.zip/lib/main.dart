import 'package:flutter/material.dart';
import 'Provider/provider.dart';
import 'Screens/Pages/Splash/splsh_screen.dart';
import 'package:provider/provider.dart';

void main(){

  runApp(DermEase());
}
class DermEase extends StatelessWidget{
  const DermEase({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
        create: (context) => AppProvider(), // Provide an instance of AppProvider
        child: Consumer<AppProvider>(
        builder: (context, appProvider, _) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
          title: 'DermEase',
          theme: ThemeData.light(), // Light theme
          darkTheme: ThemeData.dark(), // Dark theme
          themeMode: appProvider.isDarkModeEnabled
              ? ThemeMode.dark
              : ThemeMode.light, // Use themeMode to switch between light and dark mode
          home: SplashScreen(),

      );
      },

    ));







  }
}



