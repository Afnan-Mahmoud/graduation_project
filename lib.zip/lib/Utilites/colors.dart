import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/cupertino.dart';
import 'package:google_fonts/google_fonts.dart';
class ToolsUtilites {

  static const primarycolor = Color(0xff427d9d);
  static const Scendrycolor = Color(0xffffffff);
  static const facebookcolor = Color(0xff0B60B0);
  static const mainColor = Color(0xff427D9D);
  static const secondColor = Color(0xff353636);
  static const whiteColor = Color(0xfff2fcff);
  static const theardColor = Color(0x96c5c1c1);

  final primaryfont = Text("",
      style: GoogleFonts.handlee(
        fontSize: 35,
        height: 1.335,
        color: const Color(0xff427d9d),
      ));

}

